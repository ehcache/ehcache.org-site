var pairs =
{
"cache":{"extensions":1}
}
;Search.control.loadWordPairs(pairs);
