var pairs =
{
"cache":{"eviction":1}
,"eviction":{"algorithms":1}
}
;Search.control.loadWordPairs(pairs);
