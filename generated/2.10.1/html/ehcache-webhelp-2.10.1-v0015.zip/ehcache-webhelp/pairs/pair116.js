var pairs =
{
"class":{"loading":1}
}
;Search.control.loadWordPairs(pairs);
