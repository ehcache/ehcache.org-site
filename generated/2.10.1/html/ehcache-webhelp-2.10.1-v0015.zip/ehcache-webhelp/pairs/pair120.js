var pairs =
{
"ehcache":{"configuration":1}
,"configuration":{"guide":1}
}
;Search.control.loadWordPairs(pairs);
