var pairs =
{
"configuring":{"cache":1}
}
;Search.control.loadWordPairs(pairs);
