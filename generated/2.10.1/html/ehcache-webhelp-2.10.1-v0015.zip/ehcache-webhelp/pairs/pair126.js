var pairs =
{
"configuring":{"storage":1}
,"storage":{"tiers":1}
}
;Search.control.loadWordPairs(pairs);
