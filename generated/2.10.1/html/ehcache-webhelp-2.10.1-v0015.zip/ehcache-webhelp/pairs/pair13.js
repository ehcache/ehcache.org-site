var pairs =
{
"installation":{"guide":1}
}
;Search.control.loadWordPairs(pairs);
