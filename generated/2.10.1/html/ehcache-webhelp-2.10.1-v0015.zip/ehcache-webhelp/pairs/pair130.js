var pairs =
{
"sizing":{"storage":1}
,"storage":{"tiers":1}
}
;Search.control.loadWordPairs(pairs);
