var pairs =
{
"managing":{"data":1}
,"data":{"life":1}
}
;Search.control.loadWordPairs(pairs);
