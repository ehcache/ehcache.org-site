var pairs =
{
"configuring":{"restartability":1}
,"restartability":{"persistence":1}
}
;Search.control.loadWordPairs(pairs);
