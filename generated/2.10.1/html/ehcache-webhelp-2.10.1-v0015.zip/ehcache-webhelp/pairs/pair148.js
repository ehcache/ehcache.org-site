var pairs =
{
"configuring":{"update":1}
,"update":{"checker":1}
}
;Search.control.loadWordPairs(pairs);
