var pairs =
{
"system":{"properties":1}
}
;Search.control.loadWordPairs(pairs);
