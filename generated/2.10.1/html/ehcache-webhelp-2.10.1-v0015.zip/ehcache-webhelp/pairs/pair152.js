var pairs =
{
"ehcache":{"operations":1}
,"operations":{"guide":1}
}
;Search.control.loadWordPairs(pairs);
