var pairs =
{
"tuning":{"garbage":1}
,"garbage":{"collection":1}
}
;Search.control.loadWordPairs(pairs);
