var pairs =
{
"monitoring":{"management":1}
,"management":{"using":1}
,"using":{"jmx":1}
}
;Search.control.loadWordPairs(pairs);
