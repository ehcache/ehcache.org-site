var pairs =
{
"product":{"documentation":1}
}
;Search.control.loadWordPairs(pairs);
