var pairs =
{
"jmx":{"tutorial":1}
,"tutorial":{"<<this":1}
,"<<this":{"topic":1}
,"topic":{"shared":1}
,"shared":{"ehc":1}
,"ehc":{"bmg":1}
,"bmg":{"bmm":1}
,"bmm":{"product":1}
,"product":{"docs.see":1}
,"docs.see":{"online":1}
,"online":{"tutorial":1}
}
;Search.control.loadWordPairs(pairs);
