var pairs =
{
}
;Search.control.loadWordPairs(pairs);
