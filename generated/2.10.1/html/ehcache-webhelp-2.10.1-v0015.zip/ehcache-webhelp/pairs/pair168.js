var pairs =
{
"shutting":{"down":1}
,"down":{"ehcache":1}
}
;Search.control.loadWordPairs(pairs);
