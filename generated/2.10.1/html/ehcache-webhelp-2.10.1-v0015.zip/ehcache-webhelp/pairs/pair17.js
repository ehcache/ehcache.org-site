var pairs =
{
"ehcache":{"developer":1}
,"developer":{"guide":1}
}
;Search.control.loadWordPairs(pairs);
