var pairs =
{
"debugging":{"monitoring":1}
,"monitoring":{"replicated":1}
,"replicated":{"caches":1}
}
;Search.control.loadWordPairs(pairs);
