var pairs =
{
"ehcache":{"recipes":1}
}
;Search.control.loadWordPairs(pairs);
