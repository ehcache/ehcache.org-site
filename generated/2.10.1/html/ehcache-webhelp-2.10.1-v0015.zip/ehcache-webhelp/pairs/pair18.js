var pairs =
{
"key":{"classes":1}
,"classes":{"methods":1}
}
;Search.control.loadWordPairs(pairs);
