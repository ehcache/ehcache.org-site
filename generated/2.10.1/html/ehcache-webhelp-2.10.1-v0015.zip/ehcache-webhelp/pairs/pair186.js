var pairs =
{
"reference":{"documentation":1}
,"documentation":{"ehcache":1}
,"ehcache":{"2.10.1":1}
,"2.10.1":{"javadoc":1}
,"javadoc":{"ehcache.xml":1}
,"ehcache.xml":{"ehcache.xsd":1}
,"ehcache.xsd":{"release":1}
,"release":{"platform":1}
,"platform":{"compatibility":1}
,"compatibility":{"tables":1}
}
;Search.control.loadWordPairs(pairs);
