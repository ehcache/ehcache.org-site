var pairs =
{
"related":{"documentation":1}
}
;Search.control.loadWordPairs(pairs);
