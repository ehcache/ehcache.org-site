var pairs =
{
"web":{"cache":1}
,"cache":{"user":1}
,"user":{"guide":1}
}
;Search.control.loadWordPairs(pairs);
