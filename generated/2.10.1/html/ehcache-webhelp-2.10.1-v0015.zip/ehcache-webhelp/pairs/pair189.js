var pairs =
{
"web":{"cache":1}
,"cache":{"module":1}
}
;Search.control.loadWordPairs(pairs);
