var pairs =
{
"caching":{"web":1}
,"web":{"pages":1}
,"pages":{"page":1}
,"page":{"fragments":1}
}
;Search.control.loadWordPairs(pairs);
