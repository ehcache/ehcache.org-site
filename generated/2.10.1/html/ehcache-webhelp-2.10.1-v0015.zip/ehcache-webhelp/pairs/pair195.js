var pairs =
{
"sample":{"web.xml":1}
,"web.xml":{"configuration":1}
}
;Search.control.loadWordPairs(pairs);
