var pairs =
{
"ehcache":{"replication":1}
,"replication":{"guide":1}
}
;Search.control.loadWordPairs(pairs);
