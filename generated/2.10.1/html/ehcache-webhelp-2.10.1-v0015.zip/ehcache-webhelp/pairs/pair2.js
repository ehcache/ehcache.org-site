var pairs =
{
"ehcache":{"2.10":1,"release":1}
,"2.10":{"release":1}
,"release":{"notes":1,"information":1}
,"notes":{"detailed":1,"ehcache":1}
,"detailed":{"information":1}
,"information":{"new":1,"page":1}
,"new":{"ehcache":1}
}
;Search.control.loadWordPairs(pairs);
