var pairs =
{
"using":{"replication":1}
}
;Search.control.loadWordPairs(pairs);
