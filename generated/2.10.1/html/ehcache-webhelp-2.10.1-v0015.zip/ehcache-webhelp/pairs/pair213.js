var pairs =
{
"replicated":{"caching":1}
,"caching":{"using":1}
,"using":{"jgroups":1}
}
;Search.control.loadWordPairs(pairs);
