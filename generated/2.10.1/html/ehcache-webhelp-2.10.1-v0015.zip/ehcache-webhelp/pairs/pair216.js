var pairs =
{
"peer":{"discovery":1}
,"discovery":{"udp":1}
,"udp":{"multicast":1}
,"multicast":{"stack":1}
,"stack":{"additional":1,"need":1}
,"additional":{"configuration":1}
,"configuration":{"tcp":1}
,"tcp":{"stack":1}
,"need":{"specify":1}
,"specify":{"initial":1}
,"initial":{"hosts":1}
,"hosts":{"cluster":1}
}
;Search.control.loadWordPairs(pairs);
