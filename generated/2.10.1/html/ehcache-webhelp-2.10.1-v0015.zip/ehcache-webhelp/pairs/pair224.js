var pairs =
{
"replicated":{"caching":1}
,"caching":{"using":1}
,"using":{"jms":1}
}
;Search.control.loadWordPairs(pairs);
