var pairs =
{
"basic":{"caching":1}
}
;Search.control.loadWordPairs(pairs);
