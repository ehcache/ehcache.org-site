var pairs =
{
"downloading":{"installing":1}
,"installing":{"ehcache":1}
,"ehcache":{"hibernate":1}
,"hibernate":{"hibernate":1,"provider":1}
,"provider":{"ehcache-core":1}
,"ehcache-core":{"module":1}
,"module":{"download":1,"http:\u002F\u002Fsourceforge.net\u002Fprojects\u002Fehcache\u002Ffiles\u002Fehcache-core\u002F":1}
,"download":{"latest":1}
,"latest":{"version":1}
,"version":{"module":1}
}
;Search.control.loadWordPairs(pairs);
