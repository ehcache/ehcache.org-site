var pairs =
{
"demo":{"application":1}
,"application":{"tutorial":1,"available":1,"http:\u002F\u002Fsvn.terracotta.org\u002Fsvn\u002Fforge\u002Fprojects\u002Fhibernate-tutorial-web\u002Ftrunk":1}
,"tutorial":{"demo":1}
,"available":{"shows":1}
,"shows":{"hibernate":1}
,"hibernate":{"cacheregionfactory":1}
,"cacheregionfactory":{"download":1}
,"download":{"application":1}
}
;Search.control.loadWordPairs(pairs);
