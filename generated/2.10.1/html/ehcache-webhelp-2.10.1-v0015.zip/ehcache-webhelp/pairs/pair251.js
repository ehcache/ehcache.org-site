var pairs =
{
"using":{"ehcache":1}
,"ehcache":{"coldfusion":1}
}
;Search.control.loadWordPairs(pairs);
