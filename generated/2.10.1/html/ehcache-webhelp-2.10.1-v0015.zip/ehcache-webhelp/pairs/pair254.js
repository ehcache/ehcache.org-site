var pairs =
{
"using":{"ehcache":1}
,"ehcache":{"spring":1}
}
;Search.control.loadWordPairs(pairs);
