var pairs =
{
"using":{"ehcache":1}
,"ehcache":{"jruby":1}
,"jruby":{"rails":1}
}
;Search.control.loadWordPairs(pairs);
