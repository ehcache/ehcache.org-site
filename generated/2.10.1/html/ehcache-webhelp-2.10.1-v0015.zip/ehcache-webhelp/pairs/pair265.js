var pairs =
{
"using":{"ehcache":1}
,"ehcache":{"google":1}
,"google":{"app":1}
,"app":{"engine":1}
}
;Search.control.loadWordPairs(pairs);
