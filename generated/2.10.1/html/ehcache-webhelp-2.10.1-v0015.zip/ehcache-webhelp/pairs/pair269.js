var pairs =
{
"troubleshooting":{"noclassdeffounderror":1}
,"noclassdeffounderror":{"error":1}
,"error":{"java.lang.noclassdeffounderror":1}
,"java.lang.noclassdeffounderror":{"java.rmi.server.uid":1}
,"java.rmi.server.uid":{"restricted":1}
,"restricted":{"class":1}
,"class":{"using":1}
,"using":{"version":1}
,"version":{"ehcache":1}
,"ehcache":{"prior":1}
,"prior":{"1.6":1}
}
;Search.control.loadWordPairs(pairs);
