var pairs =
{
"using":{"ehcache":1}
,"ehcache":{"tomcat":1}
}
;Search.control.loadWordPairs(pairs);
