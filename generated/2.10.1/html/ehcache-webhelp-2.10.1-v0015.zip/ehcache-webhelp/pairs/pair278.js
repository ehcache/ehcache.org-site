var pairs =
{
"using":{"ehcache":1}
,"ehcache":{"openjpa":1}
}
;Search.control.loadWordPairs(pairs);
