var pairs =
{
"further":{"information":1}
,"information":{"caching":1}
,"caching":{"openjpa":1}
,"openjpa":{"apache":1,"project":1}
,"apache":{"openjpa":1}
,"project":{"http:\u002F\u002Fopenjpa.apache.org\u002Fbuilds\u002F1.0.2\u002Fapache-openjpa-1.0.2\u002Fdocs\u002Fmanual\u002Fref_guide_caching.html":1}
}
;Search.control.loadWordPairs(pairs);
