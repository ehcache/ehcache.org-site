var pairs =
{
"using":{"ehcache":1}
,"ehcache":{"grails":1}
}
;Search.control.loadWordPairs(pairs);
