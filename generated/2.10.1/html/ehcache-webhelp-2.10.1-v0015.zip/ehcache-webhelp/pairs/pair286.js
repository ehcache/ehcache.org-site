var pairs =
{
"using":{"web":1}
,"web":{"sessions":1}
,"sessions":{"grails":1,"product":1}
,"grails":{"clustering":1,"app":1,"tomcat":1}
,"clustering":{"handled":1,"grails":1}
,"handled":{"terracotta":1}
,"terracotta":{"web":1,"http:\u002F\u002Fgquick.blogspot.com\u002F2010\u002F03\u002Fclustering-grails-app-with-terracotta.html":1}
,"product":{"article":1}
,"article":{"clustering":1}
,"app":{"terracotta":1}
,"http:\u002F\u002Fgquick.blogspot.com\u002F2010\u002F03\u002Fclustering-grails-app-with-terracotta.html":{"information":1}
,"information":{"web":1}
}
;Search.control.loadWordPairs(pairs);
