var pairs =
{
"using":{"ehcache":1}
,"ehcache":{"glassfish":1}
}
;Search.control.loadWordPairs(pairs);
