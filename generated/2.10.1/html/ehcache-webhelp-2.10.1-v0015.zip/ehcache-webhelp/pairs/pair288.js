var pairs =
{
"tested":{"versions":1,"used":1,"glassfish":1}
,"versions":{"glassfish":1}
,"glassfish":{"ehcache":1,"particular":1}
,"ehcache":{"tested":1,"1.4":1,"2.0":1}
,"used":{"production":1}
,"production":{"glassfish":1}
,"particular":{"ehcache":1}
,"1.4":{"-1.7":1}
,"-1.7":{"tested":1}
,"2.0":{"tested":1}
}
;Search.control.loadWordPairs(pairs);
