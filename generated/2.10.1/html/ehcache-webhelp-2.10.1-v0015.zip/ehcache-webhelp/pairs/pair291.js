var pairs =
{
"using":{"ehcache":1}
,"ehcache":{"jsr107":1}
}
;Search.control.loadWordPairs(pairs);
