var pairs =
{
"ehcache":{"support":1}
,"support":{"jsr107":1}
,"jsr107":{"information":1,"available":1}
,"information":{"ehcache":1}
,"available":{"github":1}
,"github":{"https:\u002F\u002Fgithub.com\u002Fjsr107\u002Fehcache-jcache":1}
}
;Search.control.loadWordPairs(pairs);
