var pairs =
{
"questions":{"configuration":1}
}
;Search.control.loadWordPairs(pairs);
