var pairs =
{
"questions":{"development":1}
}
;Search.control.loadWordPairs(pairs);
