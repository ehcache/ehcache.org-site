var pairs =
{
"cache":{"usage":1}
,"usage":{"patterns":1}
}
;Search.control.loadWordPairs(pairs);
