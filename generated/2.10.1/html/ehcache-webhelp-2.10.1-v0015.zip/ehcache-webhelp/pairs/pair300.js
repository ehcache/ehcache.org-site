var pairs =
{
"questions":{"environment":1}
,"environment":{"interoperability":1}
}
;Search.control.loadWordPairs(pairs);
