var pairs =
{
"questions":{"operations":1}
}
;Search.control.loadWordPairs(pairs);
