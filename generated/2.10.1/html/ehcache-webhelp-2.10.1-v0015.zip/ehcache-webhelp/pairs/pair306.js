var pairs =
{
"questions":{"troubleshooting":1}
}
;Search.control.loadWordPairs(pairs);
