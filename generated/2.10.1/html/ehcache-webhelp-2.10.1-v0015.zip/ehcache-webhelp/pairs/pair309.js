var pairs =
{
"questions":{"errors":1}
,"errors":{"warnings":1}
}
;Search.control.loadWordPairs(pairs);
