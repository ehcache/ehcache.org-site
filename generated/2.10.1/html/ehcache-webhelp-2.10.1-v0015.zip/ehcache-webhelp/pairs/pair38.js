var pairs =
{
"searching":{"cache":1}
}
;Search.control.loadWordPairs(pairs);
