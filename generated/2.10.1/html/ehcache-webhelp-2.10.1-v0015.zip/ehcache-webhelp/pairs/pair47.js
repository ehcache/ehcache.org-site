var pairs =
{
"using":{"explicit":1}
,"explicit":{"locking":1}
}
;Search.control.loadWordPairs(pairs);
